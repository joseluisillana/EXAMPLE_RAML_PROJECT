package net.apispark.webapi.representation;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;

public class InputBodyStructuredLog_Inbound_call_Location_Geolocation {
    /** Default serial version ID. */
    private static final long serialVersionUID = 1L;

    private java.lang.String lon;

    
    public java.lang.String getLon() {
        return lon;
    }

    public void setLon(java.lang.String lon) {
        this.lon = lon;
    }


    private java.lang.String lat;

    
    public java.lang.String getLat() {
        return lat;
    }

    public void setLat(java.lang.String lat) {
        this.lat = lat;
    }

}
