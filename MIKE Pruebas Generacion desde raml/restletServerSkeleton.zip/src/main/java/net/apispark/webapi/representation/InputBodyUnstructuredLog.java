package net.apispark.webapi.representation;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;

public class InputBodyUnstructuredLog {
    /** Default serial version ID. */
    private static final long serialVersionUID = 1L;

    private java.lang.String message;

    
    public java.lang.String getMessage() {
        return message;
    }

    public void setMessage(java.lang.String message) {
        this.message = message;
    }

}
