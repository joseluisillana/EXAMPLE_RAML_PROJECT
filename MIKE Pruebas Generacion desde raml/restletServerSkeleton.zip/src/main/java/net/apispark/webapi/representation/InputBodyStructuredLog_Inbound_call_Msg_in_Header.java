package net.apispark.webapi.representation;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;

public class InputBodyStructuredLog_Inbound_call_Msg_in_Header {
    /** Default serial version ID. */
    private static final long serialVersionUID = 1L;
}
