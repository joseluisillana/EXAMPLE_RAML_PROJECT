package net.apispark.webapi.representation;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;

public class ResponseStructuredDefault_Response_body {
    /** Default serial version ID. */
    private static final long serialVersionUID = 1L;
}
