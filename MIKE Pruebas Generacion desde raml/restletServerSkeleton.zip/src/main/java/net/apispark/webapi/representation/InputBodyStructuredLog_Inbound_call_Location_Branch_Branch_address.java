package net.apispark.webapi.representation;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;

public class InputBodyStructuredLog_Inbound_call_Location_Branch_Branch_address {
    /** Default serial version ID. */
    private static final long serialVersionUID = 1L;

    private java.lang.String post_code;

    
    public java.lang.String getPost_code() {
        return post_code;
    }

    public void setPost_code(java.lang.String post_code) {
        this.post_code = post_code;
    }


    private java.lang.String province;

    
    public java.lang.String getProvince() {
        return province;
    }

    public void setProvince(java.lang.String province) {
        this.province = province;
    }


    private java.lang.String country;

    
    public java.lang.String getCountry() {
        return country;
    }

    public void setCountry(java.lang.String country) {
        this.country = country;
    }

}
