package net.apispark.webapi.representation;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;

public class InputBodyStructuredLog_Inbound_call_Msg_out {
    /** Default serial version ID. */
    private static final long serialVersionUID = 1L;

    private java.lang.String body;

    
    public java.lang.String getBody() {
        return body;
    }

    public void setBody(java.lang.String body) {
        this.body = body;
    }


    private java.lang.String header;

    
    public java.lang.String getHeader() {
        return header;
    }

    public void setHeader(java.lang.String header) {
        this.header = header;
    }

}
