package net.apispark.webapi.representation;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;

public class ResponseGetStructuredLog_Response_body_Outbound_calls {
    /** Default serial version ID. */
    private static final long serialVersionUID = 1L;

    private java.lang.String uuaa;

    
    public java.lang.String getUuaa() {
        return uuaa;
    }

    public void setUuaa(java.lang.String uuaa) {
        this.uuaa = uuaa;
    }


    private java.lang.String srv_href;

    
    public java.lang.String getSrv_href() {
        return srv_href;
    }

    public void setSrv_href(java.lang.String srv_href) {
        this.srv_href = srv_href;
    }


    private java.lang.String srv_type;

    
    public java.lang.String getSrv_type() {
        return srv_type;
    }

    public void setSrv_type(java.lang.String srv_type) {
        this.srv_type = srv_type;
    }

}
