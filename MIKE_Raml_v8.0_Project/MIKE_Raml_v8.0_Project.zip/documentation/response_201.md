-- M.I.K.E API-- 
method: Post
path: /log/structured
description: This method is to send a new log to the box which is structured following the canonical model. 
message: M.I.K.E - Created OK.
